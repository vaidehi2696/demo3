package com.vaidehi.demo3;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;


@RestController
@RequestMapping("/")
public class Demo3Controller {

    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private Demo3RateService exchangeRateService;

    @RequestMapping(value = "/list", method = RequestMethod.GET)
    public ResponseEntity<List<Demo3ConversionRate>> listAllRates() {
        log.debug("Listing all rates");
        List<Demo3ConversionRate> rates = exchangeRateService.getAllRates();

        if (rates == null || rates.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Demo3ConversionRate>>(rates, HttpStatus.OK);
    }

    @RequestMapping(value = "/all/{date}", method = RequestMethod.GET)
    public ResponseEntity<List<Demo3ConversionRate>> getAllByDate(
            @PathVariable("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {
        log.debug("Get all by date" + date);
        List<Demo3ConversionRate> rates = exchangeRateService.getAllRatesByDate(date);

        if (rates == null || rates.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Demo3ConversionRate>>(rates, HttpStatus.OK);
    }

    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public ResponseEntity<List<Demo3ConversionRate>> getAllByCurrency(@RequestParam("cur") String currency) {
        log.debug("Get all by currency" + currency);
        List<Demo3ConversionRate> rates = exchangeRateService.getAllRatesByCurrency(currency);

        if (rates == null || rates.isEmpty()) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<List<Demo3ConversionRate>>(rates, HttpStatus.OK);
    }

    @RequestMapping(value = "/{date}", method = RequestMethod.GET)
    public ResponseEntity<Demo3ConversionRate> getByDateAndCurrency(
            @PathVariable("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,
            @RequestParam("cur") String currency) {
        log.debug("Get by date: " + date + " and currency: " + currency);
        Demo3ConversionRate rate = exchangeRateService.getByDateAndCurrency(date, currency);

        if (rate == null) {
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<Demo3ConversionRate>(rate, HttpStatus.OK);
    }

    // CONVERSION
    @RequestMapping(value = "/convert", method = RequestMethod.GET)
    public ResponseEntity convertByDateAndCurrency(
            @RequestParam("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date,
            @RequestParam("fromCurrency") String fromCurrency,
            @RequestParam("toCurrency") String toCurrency,
            @RequestParam("amount") Double amount) {
        log.debug("Convert by date: {}, from {}, to {}, amount:{}", date, fromCurrency, toCurrency, amount);

        Double value = exchangeRateService.convert(date, fromCurrency, toCurrency, amount);

        if (value == null) {
            return new ResponseEntity(HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<Double>(value, HttpStatus.OK);
    }
}
