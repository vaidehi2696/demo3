package com.vaidehi.demo3.Data.service;

import com.vaidehi.demo3.Data.domain.Demo3ConversionRate;
import com.vaidehi.demo3.Data.xml.Cube;
import com.vaidehi.demo3.Data.xml.Envelope;
import com.vaidehi.demo3.Data.xml.TimeCube;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

@Service
public class Demo3LookupService
{



        private final Logger log = LoggerFactory.getLogger(this.getClass());

        @Value("${ecb.webservice.url}")
        private String url;

        private final RestTemplate restTemplate;

        public Demo3LookupService(RestTemplateBuilder restTemplateBuilder) {
            this.restTemplate = restTemplateBuilder.build();
        }

        @Async
        public Collection<Demo3ConversionRate> getUpdatedRates() throws Exception {
            log.info("Start getting updated exchange rates");

            log.debug("getting Envelope");
            Envelope envelope = getEnvelope();

            log.debug("transform Envelope into collection of ExchangeRate");
            Collection<Demo3ConversionRate> rates = transformEnvelopeToExchangeRates(envelope);

            return rates;
        }

        private Collection<Demo3ConversionRate> transformEnvelopeToExchangeRates(Envelope envelope) throws Exception {
            LinkedList<Demo3ConversionRate> rates = new LinkedList<>();

            List<TimeCube> timeCubes = envelope.getTimeCubeList().getTimeCube();
            timeCubes.stream().forEach(timeCube -> transformTimeCube(timeCube, rates));

            return rates;
        }

        private void transformTimeCube(TimeCube timeCube, LinkedList<Demo3ConversionRate> rates) {
            Date date = parseDate(timeCube);
            timeCube.getCubes().stream().forEach(cube -> transformCube(cube, date, rates));
        }

        private Date parseDate(TimeCube timeCube) {
            String timeString = timeCube.getTime();
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date date;
            try {
                date = simpleDateFormat.parse(timeString);
            } catch (ParseException e) {
                log.error("Cannot parse date: " + timeString, e);
                return null;
            }
            return date;
        }

        private void transformCube(Cube cube, Date date, LinkedList<Demo3ConversionRate> rates) {
            Demo3ConversionRate exchangeRate = new Demo3ConversionRate(cube.getCurrency(), cube.getRate(), date);
            rates.add(exchangeRate);
        }

        private Envelope getEnvelope() {
            Envelope envelope = restTemplate.getForObject(url, Envelope.class);

            return envelope;
        }

}


