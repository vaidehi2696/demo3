package com.vaidehi.demo3.Data.service;

import com.vaidehi.demo3.Data.domain.Demo3ConversionRate;
import com.vaidehi.demo3.Data.repository.Demo3ConversionRateRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import java.util.Collection;
import java.util.Date;
import java.util.List;

@Service
public class Demo3RateService
{
    private final Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private EntityManager entityManager;

    @Autowired
    private Demo3ConversionRateRepository exchangeRateRepository;

    @Transactional
    public void updateRates(Collection<Demo3ConversionRate> rates) {
        log.debug("Deleting all rates");
        exchangeRateRepository.findAll().forEach(rate -> exchangeRateRepository.delete(rate));
        entityManager.flush();

        log.debug("Writing new rates");
        rates.stream().forEach(rate -> entityManager.persist(rate));
    }

    public List<Demo3ConversionRate> getAllRates() {
        return exchangeRateRepository.findAll();
    }

    public List<Demo3ConversionRate> getAllRatesByDate(Date date) {
        return exchangeRateRepository.findAllByDate(date);
    }

    public List<Demo3ConversionRate> getAllRatesByCurrency(String currency) {
        return exchangeRateRepository.findAllByCurrency(currency);
    }

    public Demo3ConversionRate getByDateAndCurrency(Date date, String currency) {
        return exchangeRateRepository.findByDateAndCurrency(date, currency);
    }

    public Double convert(Date date, String fromCurrency, String toCurrency, Double amount) {
        if (date == null) {
            date = new Date();
        }

        double fromExchangeRateVal = 1f;
        double toExchangeRateVal = 1f;

        try {
            fromExchangeRateVal = getExchangeRateValue(date, fromCurrency, fromExchangeRateVal);
            toExchangeRateVal = getExchangeRateValue(date, toCurrency, toExchangeRateVal);

            return (amount * toExchangeRateVal) / fromExchangeRateVal;
        } catch (Exception e) {
            log.error("Error on conversion", e);
            return null;
        }
    }

    private double getExchangeRateValue(Date date, String currency, double exchangeRateVal) {
        if (!"EUR".equalsIgnoreCase(currency)) {
            Demo3ConversionRate exchangeRate = exchangeRateRepository.findByDateAndCurrency(date, currency);
            exchangeRateVal = exchangeRate.getRate();
        }

        return exchangeRateVal;
    }

}

