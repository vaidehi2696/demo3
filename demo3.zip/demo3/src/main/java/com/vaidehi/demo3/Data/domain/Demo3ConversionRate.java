package com.vaidehi.demo3.Data.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.vaidehi.demo3.Data.repository.Demo3ConversionRateRepository;
import com.vaidehi.demo3.Demo3Application;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Table(uniqueConstraints = @UniqueConstraint(columnNames = { "currency", "date" }))
@Entity
public class Demo3ConversionRate implements Serializable
{
    private static final Logger log = LoggerFactory.getLogger(Demo3Application.class);
    @Id
    @Transient
    private Long id;

    @Transient

    private static final long serialVersionUID = 2432078397208040228L;

    @Transient
    @JsonIgnore
    private String currency;

    @Column(nullable = false)
    private Double rate;

    @Column(nullable = false)
    @JsonFormat(pattern = "yyyy-MM-dd")
    private Date date;

    protected Demo3ConversionRate(Demo3ConversionRateRepository repository) {
        log.info("List");
        for(Demo3ConversionRate conversionRate: repository.findAll()){
            log.info(conversionRate.toString());
        }
        log.info("");
        // required by JPA spec
    }

    public Demo3ConversionRate(String currency, Double rate, Date date) {
        this.currency = currency;
        this.rate = rate;
        this.date = date;
    }

    public Demo3ConversionRate() {

    }

    public Long getId() {
        return id;
    }

    public String getCurrency() {
        return currency;
    }

    public Double getRate() {
        return rate;
    }

    public void setRate(Double rate) {
        this.rate = rate;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "ExchangeRate [id=" + id + ", currency=" + currency + ", rate=" + rate + ", date=" + date + "]";
    }
}




