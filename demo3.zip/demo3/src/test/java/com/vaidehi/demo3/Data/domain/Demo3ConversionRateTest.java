package com.vaidehi.demo3.Data.domain;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Date;

 @RunWith(SpringRunner.class)
 @DataJpaTest
 public class Demo3ConversionRateTest {

        @Autowired
        private TestEntityManager entityManager;

        @Autowired
        private com.vaidehi.demo3.Data.repository.Demo3ConversionRateRepository exchangeRateRepository;

        @Test
        public void testFindByName() {
            Double excRate = 1.0;
            entityManager.persist(new Demo3ConversionRate("EUR", excRate, new Date()));

            Demo3ConversionRate rate = exchangeRateRepository.findByCurrency("EUR");
            Assertions.assertEquals(excRate, rate.getRate());
        }

    }

